import gurobipy as grb

# Set of boxes
Boxes = ['Box 1','Box 2','Box 3','Box 4']

# Set of tools
Tools = ['Tool 1','Tool 2', 'Tool 3', 'Tool 4', 'Tool 5']

# Prices ($) per box
Price = {'Box 1': 100,'Box 2': 120,'Box 3': 280,'Box 4': 200}

# Dictionary with - 1 if tool is inside the box 0 otherwise
ToolInBox = {}
ToolInBox[('Box 1','Tool 1')] = 1
ToolInBox[('Box 2','Tool 1')] = 0
ToolInBox[('Box 3','Tool 1')] = 1
ToolInBox[('Box 4','Tool 1')] = 0
ToolInBox[('Box 1','Tool 2')] = 0
ToolInBox[('Box 2','Tool 2')] = 1
ToolInBox[('Box 3','Tool 2')] = 1
ToolInBox[('Box 4','Tool 2')] = 0
ToolInBox[('Box 1','Tool 3')] = 1
ToolInBox[('Box 2','Tool 3')] = 1
ToolInBox[('Box 3','Tool 3')] = 0
ToolInBox[('Box 4','Tool 3')] = 1
ToolInBox[('Box 1','Tool 4')] = 0
ToolInBox[('Box 2','Tool 4')] = 1
ToolInBox[('Box 3','Tool 4')] = 0
ToolInBox[('Box 4','Tool 4')] = 1
ToolInBox[('Box 1','Tool 5')] = 0
ToolInBox[('Box 2','Tool 5')] = 0
ToolInBox[('Box 3','Tool 5')] = 0
ToolInBox[('Box 4','Tool 5')] = 1

# Calling the optimization Model
opt_model = grb.Model()

# Variables: Binary variable which is 1 if box is bought 0 otherwise
BuyBox  = {i: opt_model.addVar(vtype=grb.GRB.BINARY, 
                        name="BuyBox_{0}".format(i)) 
for i in Boxes}

# Constraints: at least one tool of each type is needed
ConsAtLeastOneTool = {j : 
opt_model.addConstr(
        lhs=grb.quicksum(ToolInBox[i,j]*BuyBox[i] for i in Boxes),
        sense=grb.GRB.GREATER_EQUAL,
        rhs=1, 
        name="ConsAtLeastOneTool_{0}".format(j))
    for j in Tools}


# Objective Function: Minimize total purchasing cost of boxes
objective = grb.quicksum(Price[i]*BuyBox[i] for i in Boxes)
opt_model.ModelSense = grb.GRB.MINIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results
for v in opt_model.getVars():
  print('%s %g' % (v.varName, v.x))
