import gurobipy as grb

# Set of bottles
Bottles = ['A','B','C']

# Price per litre per bottle
PricePerL = {'A':10,'B':20,'C':30}

# Capacity per bottle (in L)
Capacity  = {'A':2.0,'B':1.5,'C':0.5}

# Calling the optimization Model
opt_model = grb.Model()

# Variables: Water (in L) per bottle used. Type Continuous non negative
WaterPerBottle  = {i: opt_model.addVar(vtype=grb.GRB.CONTINUOUS, 
                        lb=0, 
                        name="WaterPerBottle_{0}".format(i)) 
for i in Bottles}

# Constraints: don't use more capacity than limit of each bottle
ConsBottleCapacity = {i : 
opt_model.addConstr(
        lhs=WaterPerBottle[i],
        sense=grb.GRB.LESS_EQUAL,
        rhs=Capacity[i], 
        name="ConsBottleCapacity_{0}".format(i))
    for i in Bottles}

# Constraints: we have to fill exactly 2.5 liters
ConsTotalLiters = opt_model.addConstr(
        lhs=grb.quicksum(WaterPerBottle[i] for i in Bottles),
        sense=grb.GRB.EQUAL,
        rhs=2.5, 
        name="ConsTotalLiters")

# Objective Function: Maximize Total value of water used to fill our bottle
objective = grb.quicksum(PricePerL[i]*WaterPerBottle[i] for i in Bottles)
opt_model.ModelSense = grb.GRB.MAXIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results
for v in opt_model.getVars():
  print('%s %g' % (v.varName, v.x))
