import gurobipy as grb
import random as rnd


UserInput = int(input('Enter the number of Vertices (integer bigger than 0):'))

try:

  # Number of vertices in the graph - got by the user
  NumOfVertices = UserInput - 1

  # Set of vertices (indexes)
  SetOfVertices = [i for i in range(NumOfVertices)]

  # Maximum edges per vertex, which is the number of vertices divided by 2
  MaxEdgesPerVertex = int(NumOfVertices/2)

  # Adjacency Matrix (VxX) - is equal to 1 if edge (i,j) exist, 0 otherwise
  AdjacencyMatrix = {}

  # Total number of edges per vertex (degree of each vertex)
  TotalEdgesPerVertex = {}

  # Start graph with all nodes but no edge between them
  for i in range(0, NumOfVertices):
    for j in range(0, NumOfVertices):
      AdjacencyMatrix[(i,j)] = 0
    TotalEdgesPerVertex[i] = 0

  # First Phase: Start from a path
  # Path: The path graph is a one with two vertices with degree 1, and the others with degree 2
  #       A path graph is therefore a graph that can be drawn so that all of its vertices and edges lie on a single straight line
  # A path is by definition a connected graph
  for i in range(0, NumOfVertices):
    if(i < NumOfVertices - 1):
      AdjacencyMatrix[i,i+1] = 1      
      AdjacencyMatrix[i+1,i] = 1
      TotalEdgesPerVertex[i] = TotalEdgesPerVertex[i] + 1
      TotalEdgesPerVertex[i+1] = TotalEdgesPerVertex[i+1] + 1

  # Second phase will be applied only if NumOfVertices is higher than 3
  #     Graphs with more than 3 vertices already reach the limit of all constraints - num_edges = {1,V/2}
  if(NumOfVertices >= 3):
  # Second Phase: Fill the other edges
  # For each edge, where degree of nodes does not exceed the limit of degree NumOfVertices/2
  #     we choose randomly if this edge exists or not (uniform distribution)
  # As we already started from a connected graph
    for i in range(0, NumOfVertices):
      for j in range(i + 1, NumOfVertices):
        if(TotalEdgesPerVertex[i] < MaxEdgesPerVertex) and (TotalEdgesPerVertex[j] < MaxEdgesPerVertex) and (AdjacencyMatrix[i,j] == 0):
          RandNumber = int(round(rnd.random(),0))
          if(RandNumber == 1):
            TotalEdgesPerVertex[i] = TotalEdgesPerVertex[i] + 1
            TotalEdgesPerVertex[j] = TotalEdgesPerVertex[j] + 1
            AdjacencyMatrix[i,j] = 1     
            AdjacencyMatrix[j,i] = 1


  # Calling the optimization Model
  opt_model = grb.Model()

  # Variables: Binary variable which is 1 if vertex is chosen 0 otherwise
  VertexIsChosen  = {i: opt_model.addVar(vtype=grb.GRB.BINARY, 
                          name="VertexIsChosen_{0}".format(i)) 
  for i in SetOfVertices}

  # Constraints: at least one vertex have to be chosen for every edge
  ConsAtLeastOneVertex = {(i,j) : 
  opt_model.addConstr(
          lhs=VertexIsChosen[i] + VertexIsChosen[j],
          sense=grb.GRB.GREATER_EQUAL,
          rhs=1, 
          name="ConsAtLeastOneVertex_{0}_{1}".format(i,j))
      for i in SetOfVertices for j in SetOfVertices if AdjacencyMatrix[i,j] == 1}

  # Objective Function: Minimize number of choses vertices
  objective = grb.quicksum(VertexIsChosen[i] for i in SetOfVertices)
  opt_model.ModelSense = grb.GRB.MINIMIZE
  opt_model.setObjective(objective)

  # Run model
  opt_model.optimize()

  # Printing results - only chosen vertices
  for v in opt_model.getVars():
    if(v.x > 0):
      print('%s %g' % (v.varName, v.x))

except ValueError:
    print("Not a number, please enter a new number")