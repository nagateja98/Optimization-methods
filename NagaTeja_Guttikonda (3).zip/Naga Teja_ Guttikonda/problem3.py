import gurobipy as grb

# Set of rows indexes in the grid
Rows = [0,1,2,3,4,5,6]

# Set of column indexes in the grid
Columns = [0,1,2,3,4,5,6]

# Matrix with the value for each cell
GridValues = [[5,4,6,7,1,5,6], 
    [9,8,5,1,1,2,3], 
    [1,7,4,6,2,3,5], 
    [1,1,2,4,2,6,2], 
    [15,12,1,3,10,8,2], 
    [16,17,1,1,6,6,2], 
    [3,5,8,1,2,1,1]] 

# Calling the optimization Model
opt_model = grb.Model(name="MIP Model")

# Variables: Binary variable which is 1 if cell in row i column j is used 0 otherwise
CellIsUsed  = {(i,j): opt_model.addVar(vtype=grb.GRB.BINARY, 
                        name="x_{0}_{1}".format(i,j)) 
for i in Rows for j in Rows}

# Constraints: exactly one cell per column is selected
ConsOnePerColumn = {j :
opt_model.addConstr(
        lhs=grb.quicksum(CellIsUsed[i,j] for i in Rows),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="ConsOnePerColumn_{0}".format(j))
    for j in Columns}

# Constraints: exactly one cell per row is selected
ConsOnePerRow = {i :
opt_model.addConstr(
        lhs=grb.quicksum(CellIsUsed[i,j] for j in Columns),
        sense=grb.GRB.EQUAL,
        rhs=1, 
        name="ConsOnePerRow_{0}".format(i))
    for i in Rows}

# Objective Function: Maximize sum of cells values of those that were selected
objective = grb.quicksum(GridValues[i][j]*CellIsUsed[i,j] for i in Rows for j in Columns)
opt_model.ModelSense = grb.GRB.MAXIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results - only the row and column index of selected cells
for v in opt_model.getVars():
  if(v.x > 0):
    print('%s %g' % (v.varName, v.x))
