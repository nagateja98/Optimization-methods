import gurobipy as grb
import random

# Generate the bipartite graph and put random edges with random weights
def MyBipartiteG(N):
  # Graph is defined by three structures
  # - Adjacency List with a list of neighbors per node
  # - EdgesWeights with a weight per edge
  # - Nodes list of nodes
  Nodes = list(range(N))
  AdjacencyList = []
  for i in range(N):
    AdjacencyList.append([])
  EdgesWeights = {}
  # The first step is generate the two disjoint sets of nodes (Set1 and Set2)
  Set1 = random.randint(1, N - 1)
  Set2 = N - Set1
  # Here the edges are generated randomly together with weights
  for i in range(Set1):
    for j in range(Set2):
      RandNumber = random.randint(0,1)
      if(RandNumber == 1):
        AdjacencyList[i].append(Set1+j)
        AdjacencyList[Set1+j].append(i)
        weight = random.randint(1, 100)
        EdgesWeights[(i,Set1+j)] = weight
        EdgesWeights[(Set1+j,i)] = weight
    # If there's no neighbor for a specific node i (in Set 1), choose one in Set 2 and assign it randomly
    # With this we guarantee the property what all nodes in a bipartite graph have a neighbor in the other set
    if(len(AdjacencyList[i]) == 0):
      d2 = random.randint(0, Set2-1)
      AdjacencyList[i].append(Set1+d2)
      AdjacencyList[Set1+d2].append(i)
      weight = random.randint(1, 100)
      EdgesWeights[(i,Set1+d2)] = weight
      EdgesWeights[(Set1+d2,i)] = weight
  # If there's no neighbor for a specific node j (in Set 2), choose one in Set 1 and assign it randomly
  # With this we guarantee the property what all nodes in a bipartite graph have a neighbor in the other set
  for j in range(Set1,Set1+Set2):
    if(len(AdjacencyList[j]) == 0):
      d1 = random.randint(0, Set1-1)
      AdjacencyList[d1].append(j)
      AdjacencyList[j].append(d1)
      EdgesWeights[(d1,j)] = EdgesWeights[(j,d1)] = random.randint(1, 100)
  print("First set:", Set1, " Second set:", Set2)
  return Nodes, AdjacencyList, EdgesWeights

# Check if the generated graph G is bipartite or not
# This function relies on the fact that a graph is bipartite if it its nodes can be divided into two groups such as
#     there's no edge between nodes in a same group
def TestBipartiteG(G):
  NumNodes = len(G)
  # Initialize all nodes as belonging to the same group 
  for i in range(NumNodes): 
    group[i] = -1
  # For every node that has group -1 value check its neighbors and set it a different group value 
  #    If this is not possible graph is not bipartite
  for i in range(NumNodes):
    if(group[i] == -1):
      if(not setgroup(G, i, 0)):
        return False
  return True

# Check recursively if a node can be part of a different group than his neighbors
#     If this is not possible graph is not bipartite
def setgroup(G, v, gr):
  group[v] = gr
  for j in G[v]:
    if(group[j] == -1):
      if(not(setgroup(G, j, 1-gr))):
        return False
    else:
      if(group[j] == gr):
        return False
  return True

# Group is a global variable
group = {}

Nodes, AdjacencyList, EdgesWeights = MyBipartiteG(10)
print(AdjacencyList)
if(TestBipartiteG(AdjacencyList)):
  print("Graph is bipartite")
else:
  print("Graph is not bipartite")

# Calling the optimization Model
opt_model = grb.Model()

# Variables: Binary variable which is 1 if edge (i,j) is chosen. 0 otherwise
EdgeIsChosen  = {(i,j): opt_model.addVar(vtype=grb.GRB.BINARY, 
                        name="EdgeIsChosen_{0}_{1}".format(i,j)) 
for i in Nodes for j in AdjacencyList[i]}

# Constraints: at most one edge per node can be chosen - this guarantees the matching
ConsAtMostOneEdge = {i : 
opt_model.addConstr(
        lhs=grb.quicksum(EdgeIsChosen[i,j] for j in AdjacencyList[i]),
        sense=grb.GRB.LESS_EQUAL,
        rhs=1, 
        name="ConsAtMostOneEdge_{0}".format(i))
    for i in Nodes}

# Constraints: symmetry constraint. If (i,j) is chosen (j,i) has to be also chosen since it's the same edge 
ConsSymmetry = {(i,j) : 
opt_model.addConstr(
        lhs=EdgeIsChosen[i,j],
        sense=grb.GRB.LESS_EQUAL,
        rhs=EdgeIsChosen[j,i], 
        name="ConsSymmetry_{0}_{1}".format(i,j))
    for i in Nodes for j in AdjacencyList[i]}

# Objective Function: Maximize weight of edges/2 since we will be counting (i,j) and (j,i) 
objective = grb.quicksum(EdgesWeights[i,j]*EdgeIsChosen[i,j] for i in Nodes for j in AdjacencyList[i])/2
opt_model.ModelSense = grb.GRB.MAXIMIZE
opt_model.setObjective(objective)

# Run model
opt_model.optimize()

# Printing results - only chosen edges
for v in opt_model.getVars():
  if(v.x > 0):
    print('%s %g' % (v.varName, v.x))