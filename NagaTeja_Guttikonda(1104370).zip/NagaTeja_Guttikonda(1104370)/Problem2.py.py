import random

random.seed(80)

# Assign (match) college to students
# The algorithm relies on the fact that there will be always more students (NumberStudents) than college spots (NumberCollegeSpots)
#   College spots are defined by number of colleges * number of spots availiable per college
# College spots are numbered from 0 to NumberCollegeSpots - 1
# Students are numbered from NumberCollegeSpots to NumberCollegeSpots + NumberStudents - 1
# Pref: list of preferences by decreasing order
# Inverse: inverse of preference - pre processing
def StableAssignment(Pref, Inverse): 
  StudentCollege = [-1 for i in range(NumberStudents)] 
  SpotIsFree = [False for i in range(NumberCollegeSpots)] 
  NumberFreeCollegeSpots = NumberCollegeSpots 
  # Run algorithm until there's no college spot availiable
  while (NumberFreeCollegeSpots > 0): 
    print(NumberFreeCollegeSpots)
    # Pick the first college spot availiable
    s1 = 0
    for s1 in range(0, NumberCollegeSpots):
      if (SpotIsFree[s1] == False): 
        break
    for i in range(0, NumberCollegeSpots):
      c = Pref[s1][i] 
      # If student of preference (s1) is free assign it to c and break the loop
      if (StudentCollege[c - NumberStudents] == -1): 
        StudentCollege[c - NumberStudents] = s1 
        SpotIsFree[s1] = True
        NumberFreeCollegeSpots -= 1
        break
      else: 
        # If s1 is not free, find which college he's allocated to
        s2 = StudentCollege[c - NumberStudents] 
        # If s1 prefers c1 over her current engagement c2, 
        #    then break the assignment between s1 and c2 and assign s1 with c1
        if(Inverse[s1] < Inverse[s2]):
          StudentCollege[c - NumberStudents] = s1 
          SpotIsFree[s1] = True
          SpotIsFree[s2] = False
          break

  print("Student ", "         College") 
  for i in range(NumberStudents): 
    if(StudentCollege[i] == -1):
      print(StudentsDescription[i], "\t", "No college") 
    else:
      print(StudentsDescription[i], "\t", SpotsDescription[StudentCollege[i]]) 

NumCollege = 15
SpotsCollege = 40
NumberCollegeSpots = NumCollege*SpotsCollege
NumberStudents = 5000

# Generate all colleges, spots and students
College = [i for i in range(NumCollege)] 
CollegeSpots = [i for i in range(NumberCollegeSpots)] 
Students = []
StudentsDescription = {}
count = 0
for i in range(NumberCollegeSpots, NumberCollegeSpots + NumberStudents):
  Students.append(i)
  StudentsDescription[count] = "Student_" + str(count + 1)
  count = count + 1

SpotsIndexes = {}
SpotsDescription = {}
index = 0
for i in range(NumCollege):
  vec = []
  for j in range(SpotsCollege):
    SpotsDescription[index] = "College_" + str(j + 1)
    vec.append(index)
    index = index + 1
  SpotsIndexes[i] = vec

# Generate preference and inverse list for students and college spots
Pref = []
Inverse = []
for i in range(NumCollege):
  random.shuffle(Students)
  StudentsCopy = Students[:]
  InverseAux = [-1 for i in range(NumberCollegeSpots + NumberStudents)]
  for k in StudentsCopy:
    InverseAux[k] = StudentsCopy.index(k)
  for j in range(SpotsCollege):
    Inverse.append(InverseAux)
    Pref.append(StudentsCopy)

for i in range(NumberStudents):
  random.shuffle(College)
  CollegeCopy = College[:]
  vec = []
  for j in CollegeCopy:
    vec = vec + SpotsIndexes[j]
  Pref.append(vec)

StableAssignment(Pref,Inverse) 